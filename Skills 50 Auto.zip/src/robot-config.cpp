#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor MotorFL = motor(PORT2, ratio18_1, true);
motor MotorFR = motor(PORT21, ratio18_1, false);
motor MotorBL = motor(PORT4, ratio18_1, true);
motor MotorBR = motor(PORT8, ratio18_1, false);
motor MotorML = motor(PORT3, ratio18_1, false);
motor MotorMR = motor(PORT5, ratio18_1, true);
motor Flywheel = motor(PORT9, ratio18_1, false);
motor IntakeMotor = motor(PORT6, ratio18_1, false);
controller Controller1 = controller(primary);
motor Catapult = motor(PORT1, ratio36_1, false);
line LineTrackerCata = line(Brain.ThreeWirePort.A);
digital_out String = digital_out(Brain.ThreeWirePort.H);
optical Optical = optical(PORT15);
limit LimitSwitchB = limit(Brain.ThreeWirePort.B);
rotation RotationSensor = rotation(PORT13, false);
inertial InertialSensor = inertial(PORT14);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}