using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor MotorFL;
extern motor MotorFR;
extern motor MotorBL;
extern motor MotorBR;
extern motor MotorML;
extern motor MotorMR;
extern motor Flywheel;
extern motor IntakeMotor;
extern controller Controller1;
extern motor Catapult;
extern line LineTrackerCata;
extern digital_out String;
extern optical Optical;
extern limit LimitSwitchB;
extern rotation RotationSensor;
extern inertial InertialSensor;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );